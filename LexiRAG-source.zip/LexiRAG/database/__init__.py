"""SQLite persistence."""

